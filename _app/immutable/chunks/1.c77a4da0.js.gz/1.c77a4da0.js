import{default as t}from"../entry/error.svelte.b3802f27.js";export{t as component};
