import{default as t}from"../entry/_layout.svelte.6eb20878.js";export{t as component};
