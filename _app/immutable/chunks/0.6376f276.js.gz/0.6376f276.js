import{default as t}from"../entry/_layout.svelte.5fc23f7a.js";export{t as component};
