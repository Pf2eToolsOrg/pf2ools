import{default as t}from"../entry/_layout.svelte.420acf5d.js";export{t as component};
