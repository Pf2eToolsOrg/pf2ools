import{default as t}from"../entry/error.svelte.29db13da.js";export{t as component};
