import{default as t}from"../entry/_layout.svelte.64b210d3.js";export{t as component};
