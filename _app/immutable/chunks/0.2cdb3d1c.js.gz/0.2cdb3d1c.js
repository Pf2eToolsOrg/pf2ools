import{default as t}from"../entry/_layout.svelte.89dadd21.js";export{t as component};
