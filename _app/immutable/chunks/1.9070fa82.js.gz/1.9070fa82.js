import{default as t}from"../entry/error.svelte.6a46f77e.js";export{t as component};
