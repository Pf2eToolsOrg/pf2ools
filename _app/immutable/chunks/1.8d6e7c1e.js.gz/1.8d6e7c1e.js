import{default as t}from"../entry/error.svelte.068f8087.js";export{t as component};
