import{default as t}from"../entry/error.svelte.fa434491.js";export{t as component};
