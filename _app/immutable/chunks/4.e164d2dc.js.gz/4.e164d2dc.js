import{default as t}from"../entry/renderer-page.svelte.62a7e37d.js";export{t as component};
