import{default as t}from"../entry/_layout.svelte.427e313a.js";export{t as component};
