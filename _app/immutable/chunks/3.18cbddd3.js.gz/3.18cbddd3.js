import{default as t}from"../entry/licenses-page.svelte.4078efb3.js";export{t as component};
