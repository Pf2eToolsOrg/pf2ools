import{default as t}from"../entry/error.svelte.754912f9.js";export{t as component};
