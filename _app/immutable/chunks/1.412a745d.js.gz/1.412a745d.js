import{default as t}from"../entry/error.svelte.49f5b175.js";export{t as component};
