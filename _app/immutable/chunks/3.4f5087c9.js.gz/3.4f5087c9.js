import{default as t}from"../entry/licenses-page.svelte.c5d0339a.js";export{t as component};
