import{default as t}from"../entry/_layout.svelte.e5efccf7.js";export{t as component};
