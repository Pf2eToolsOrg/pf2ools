import{default as t}from"../entry/_layout.svelte.6edfa451.js";export{t as component};
