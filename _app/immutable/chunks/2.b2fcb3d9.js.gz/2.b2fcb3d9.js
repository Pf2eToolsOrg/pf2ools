import{default as t}from"../entry/_page.svelte.c2d11e1c.js";export{t as component};
