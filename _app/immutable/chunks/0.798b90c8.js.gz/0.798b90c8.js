import{default as t}from"../entry/_layout.svelte.f076172b.js";export{t as component};
