import{default as t}from"../entry/licenses-page.svelte.490796ae.js";export{t as component};
