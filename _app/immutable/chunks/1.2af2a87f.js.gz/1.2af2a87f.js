import{default as t}from"../entry/error.svelte.d566ec5a.js";export{t as component};
