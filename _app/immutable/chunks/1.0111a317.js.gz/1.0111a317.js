import{default as t}from"../entry/error.svelte.da9ed43c.js";export{t as component};
