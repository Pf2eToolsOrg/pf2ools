import{default as t}from"../entry/licenses-page.svelte.69c489d1.js";export{t as component};
