import{default as t}from"../entry/renderer-page.svelte.b006bd99.js";export{t as component};
