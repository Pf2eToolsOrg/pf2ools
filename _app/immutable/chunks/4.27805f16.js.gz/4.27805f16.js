import{default as t}from"../entry/renderer-page.svelte.163cda7b.js";export{t as component};
