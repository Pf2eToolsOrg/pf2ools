import{default as t}from"../entry/error.svelte.d76b6026.js";export{t as component};
