import{default as t}from"../entry/error.svelte.111e6f07.js";export{t as component};
