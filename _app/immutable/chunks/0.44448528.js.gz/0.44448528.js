import{default as t}from"../entry/_layout.svelte.b900e3b9.js";export{t as component};
