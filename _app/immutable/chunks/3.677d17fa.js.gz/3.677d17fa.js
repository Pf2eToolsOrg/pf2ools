import{default as t}from"../entry/licenses-page.svelte.8fd96698.js";export{t as component};
