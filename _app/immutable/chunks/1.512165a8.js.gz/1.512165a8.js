import{default as t}from"../entry/error.svelte.4b8a4113.js";export{t as component};
