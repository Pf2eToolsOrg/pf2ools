import{default as t}from"../entry/_layout.svelte.d3f2300b.js";export{t as component};
