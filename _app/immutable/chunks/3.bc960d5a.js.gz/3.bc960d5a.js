import{default as t}from"../entry/licenses-page.svelte.27dd1f34.js";export{t as component};
