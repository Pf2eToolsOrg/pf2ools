import{default as t}from"../entry/licenses-page.svelte.d9b2ffd7.js";export{t as component};
