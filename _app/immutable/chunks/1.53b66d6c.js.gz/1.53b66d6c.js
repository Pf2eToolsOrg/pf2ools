import{default as t}from"../entry/error.svelte.0fd99607.js";export{t as component};
