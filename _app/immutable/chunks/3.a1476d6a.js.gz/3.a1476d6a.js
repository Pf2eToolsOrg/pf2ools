import{default as t}from"../entry/licenses-page.svelte.db5e9dbb.js";export{t as component};
