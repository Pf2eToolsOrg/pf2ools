import{default as t}from"../entry/_layout.svelte.af8b573b.js";export{t as component};
