import{default as t}from"../entry/error.svelte.2a337d02.js";export{t as component};
