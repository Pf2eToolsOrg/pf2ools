import{default as t}from"../entry/error.svelte.23bc1b1b.js";export{t as component};
