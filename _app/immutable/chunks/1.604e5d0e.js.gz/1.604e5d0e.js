import{default as t}from"../entry/error.svelte.ea1bbcf3.js";export{t as component};
