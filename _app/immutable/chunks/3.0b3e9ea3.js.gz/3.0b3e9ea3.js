import{default as t}from"../entry/licenses-page.svelte.598832e4.js";export{t as component};
