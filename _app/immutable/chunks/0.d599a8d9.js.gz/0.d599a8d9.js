import{default as t}from"../entry/_layout.svelte.f33cdd7e.js";export{t as component};
