import{default as t}from"../entry/error.svelte.ada70145.js";export{t as component};
