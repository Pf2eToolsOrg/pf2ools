import{default as t}from"../entry/error.svelte.83cf3635.js";export{t as component};
