import{default as t}from"../entry/error.svelte.ab468019.js";export{t as component};
