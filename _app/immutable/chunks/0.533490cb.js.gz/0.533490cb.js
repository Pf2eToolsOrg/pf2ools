import{default as t}from"../entry/_layout.svelte.e88ac6ed.js";export{t as component};
