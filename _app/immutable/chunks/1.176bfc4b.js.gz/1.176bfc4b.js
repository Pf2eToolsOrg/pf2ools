import{default as t}from"../entry/error.svelte.8c07dc0a.js";export{t as component};
