import{default as t}from"../entry/licenses-page.svelte.ebbe29b2.js";export{t as component};
