import{default as t}from"../entry/_layout.svelte.b520a797.js";export{t as component};
