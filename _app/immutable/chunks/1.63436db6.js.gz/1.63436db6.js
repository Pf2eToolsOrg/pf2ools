import{default as t}from"../entry/error.svelte.b4b562d5.js";export{t as component};
