import{default as t}from"../entry/_layout.svelte.3bd6bda4.js";export{t as component};
