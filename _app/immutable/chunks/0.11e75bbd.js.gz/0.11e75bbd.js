import{default as t}from"../entry/_layout.svelte.2e44d3e9.js";export{t as component};
