import{default as t}from"../entry/_page.svelte.3270e54d.js";export{t as component};
