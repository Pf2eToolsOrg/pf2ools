import{default as t}from"../entry/error.svelte.79c16a14.js";export{t as component};
