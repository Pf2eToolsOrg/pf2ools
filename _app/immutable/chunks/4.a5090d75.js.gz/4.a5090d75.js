import{default as t}from"../entry/renderer-page.svelte.436c8b0e.js";export{t as component};
