const t = /* @__PURE__ */ location.pathname.split("/").slice(0, -1).join("/"), r = [
  t + "/_app/immutable/entry/app.d42d149c.js",
  t + "/_app/immutable/chunks/0.4fa46e32.js",
  t + "/_app/immutable/chunks/1.63436db6.js",
  t + "/_app/immutable/chunks/2.b2fcb3d9.js",
  t + "/_app/immutable/chunks/3.0b3e9ea3.js",
  t + "/_app/immutable/chunks/4.9a7372a1.js",
  t + "/_app/immutable/assets/ProgressBar.4f1e9ba5.css",
  t + "/_app/immutable/chunks/ProgressBar.svelte_svelte_type_style_lang.ec6fbd8a.js",
  t + "/_app/immutable/chunks/Renderer.bf7392e5.js",
  t + "/_app/immutable/chunks/index.363b4140.js",
  t + "/_app/immutable/chunks/index.69e6a8df.js",
  t + "/_app/immutable/chunks/singletons.3dbee803.js",
  t + "/_app/immutable/chunks/stores.7dba22a1.js",
  t + "/_app/immutable/entry/start.7f3c59ef.js",
  t + "/_app/immutable/entry/error.svelte.b4b562d5.js",
  t + "/_app/immutable/assets/_layout.39371f4a.css",
  t + "/_app/immutable/entry/_layout.svelte.af8b573b.js",
  t + "/_app/immutable/entry/_page.svelte.c2d11e1c.js",
  t + "/_app/immutable/entry/licenses-page.svelte.598832e4.js",
  t + "/_app/immutable/entry/renderer-page.svelte.b006bd99.js"
], g = [
  t + "/data/.git",
  t + "/data/.gitignore",
  t + "/data/CUP.license",
  t + "/data/LICENSE",
  t + "/data/README.md",
  t + "/data/core/renderdemo.json",
  t + "/data/core/sources.json",
  t + "/fonts/AlbertusMT.ttf",
  t + "/fonts/Basing.ttf",
  t + "/fonts/Blambot-Casual-Regular.ttf",
  t + "/fonts/Convergence-Regular.ttf",
  t + "/fonts/Dax-Regular.ttf",
  t + "/fonts/Dax-bold.ttf",
  t + "/fonts/Gin-Regular.ttf",
  t + "/fonts/OFL.txt",
  t + "/fonts/Pathfinder2eActions.ttf",
  t + "/fonts/Quicksand.ttf",
  t + "/fonts/Roboto-regular.ttf",
  t + "/fonts/Sabon-Bold.ttf",
  t + "/fonts/Sabon-BoldItalic.ttf",
  t + "/fonts/Sabon-Italic.ttf",
  t + "/fonts/Sabon-Roman.ttf",
  t + "/fonts/SabonLTStd-Bold.ttf",
  t + "/fonts/SabonLTStd-BoldItalic.ttf",
  t + "/fonts/SabonLTStd-Italic.ttf",
  t + "/fonts/SabonLTStd-Roman.ttf",
  t + "/fonts/Taroca.ttf",
  t + "/fonts/fa-light-300.eot",
  t + "/fonts/fa-light-300.ttf",
  t + "/fonts/fa-light-300.woff",
  t + "/fonts/fa-light-300.woff2",
  t + "/fonts/fa-regular-400.eot",
  t + "/fonts/fa-regular-400.ttf",
  t + "/fonts/fa-regular-400.woff",
  t + "/fonts/fa-regular-400.woff2",
  t + "/fonts/fa-solid-900.eot",
  t + "/fonts/fa-solid-900.ttf",
  t + "/fonts/fa-solid-900.woff",
  t + "/fonts/fa-solid-900.woff2",
  t + "/fonts/glyphicons-halflings-regular.eot",
  t + "/fonts/glyphicons-halflings-regular.svg",
  t + "/fonts/glyphicons-halflings-regular.ttf",
  t + "/fonts/glyphicons-halflings-regular.woff",
  t + "/fonts/glyphicons-halflings-regular.woff2",
  t + "/fonts/good-pro-400.ttf",
  t + "/fonts/good-pro-400.woff",
  t + "/fonts/good-pro-400.woff2",
  t + "/fonts/good-pro-700.ttf",
  t + "/fonts/good-pro-700.woff",
  t + "/fonts/good-pro-700.woff2",
  t + "/fonts/good-pro-condensed-400.ttf",
  t + "/fonts/good-pro-condensed-400.woff",
  t + "/fonts/good-pro-condensed-700.ttf",
  t + "/fonts/good-pro-condensed-700.woff",
  t + "/fonts/good-pro-condensed-700.woff2",
  t + "/fonts/good-pro-condensed-italic-400.ttf",
  t + "/fonts/good-pro-condensed-italic-400.woff",
  t + "/fonts/good-pro-condensed-italic-700.ttf",
  t + "/fonts/good-pro-condensed-italic-700.woff",
  t + "/fonts/good-pro-condensed-italic-700.woff2",
  t + "/fonts/good-pro-italic-400.ttf",
  t + "/fonts/good-pro-italic-400.woff",
  t + "/fonts/good-pro-italic-400.woff2",
  t + "/fonts/good-pro-italic-700.ttf",
  t + "/fonts/good-pro-italic-700.woff",
  t + "/fonts/good-pro-italic-700.woff2",
  t + "/fonts/languages/CRB/Draconic/Iokharic Bold Italic.otf",
  t + "/fonts/languages/CRB/Draconic/Iokharic Bold.otf",
  t + "/fonts/languages/CRB/Draconic/Iokharic Italic.otf",
  t + "/fonts/languages/CRB/Draconic/Iokharic.otf",
  t + "/fonts/languages/CRB/Dwarven/Davek Bold Italic.otf",
  t + "/fonts/languages/CRB/Dwarven/Davek Bold.otf",
  t + "/fonts/languages/CRB/Dwarven/Davek Italic.otf",
  t + "/fonts/languages/CRB/Dwarven/Davek.otf",
  t + "/fonts/languages/CRB/Dwarven/Dethek Alt.ttf",
  t + "/fonts/languages/CRB/Dwarven/Dethek Bold Italic.otf",
  t + "/fonts/languages/CRB/Dwarven/Dethek Bold.otf",
  t + "/fonts/languages/CRB/Dwarven/Dethek Italic.otf",
  t + "/fonts/languages/CRB/Dwarven/Dethek Stone.ttf",
  t + "/fonts/languages/CRB/Dwarven/Dethek.otf",
  t + "/fonts/languages/CRB/Dwarven/Olde Dethek Italic.otf",
  t + "/fonts/languages/CRB/Dwarven/Olde Dethek.otf",
  t + "/fonts/languages/CRB/Elven/Espruar 2e.ttf",
  t + "/fonts/languages/CRB/Elven/Espruar 3e Bold Italic.otf",
  t + "/fonts/languages/CRB/Elven/Espruar 3e Bold.otf",
  t + "/fonts/languages/CRB/Elven/Espruar 3e Italic.otf",
  t + "/fonts/languages/CRB/Elven/Espruar 3e.otf",
  t + "/fonts/languages/CRB/Elven/Espruar 3e.ttf",
  t + "/fonts/languages/CRB/Elven/Espruar 5e.ttf",
  t + "/fonts/languages/CRB/Elven/Olde Espruar.otf",
  t + "/fonts/languages/CRB/Elven/Rellanic Bold Italic.otf",
  t + "/fonts/languages/CRB/Elven/Rellanic Bold.otf",
  t + "/fonts/languages/CRB/Elven/Rellanic Italic.otf",
  t + "/fonts/languages/CRB/Elven/Rellanic.otf",
  t + "/fonts/languages/CRB/Human/Harpers.ttf",
  t + "/fonts/languages/CRB/Human/Olde Thorass.otf",
  t + "/fonts/languages/CRB/Human/Thorass Bold Italic.otf",
  t + "/fonts/languages/CRB/Human/Thorass Bold.otf",
  t + "/fonts/languages/CRB/Human/Thorass Italic.otf",
  t + "/fonts/languages/CRB/Human/Thorass.otf",
  t + "/fonts/languages/CRB/Infernal/Barazhad Bold Italic.otf",
  t + "/fonts/languages/CRB/Infernal/Barazhad Bold.otf",
  t + "/fonts/languages/CRB/Infernal/Barazhad Italic.otf",
  t + "/fonts/languages/CRB/Infernal/Barazhad.otf",
  t + "/fonts/languages/CRB/Infernal/Infernal.ttf",
  t + "/icons/Background.svg",
  t + "/icons/NoBackground.svg",
  t + "/icons/safari-pinned-tab.svg"
], i = "1682701351476", f = `cache-${i}`, l = [
  ...r,
  // the app itself
  ...g.filter((a) => !a.startsWith("/data"))
  // everything in `static` but the actual data
];
self.addEventListener("install", (a) => {
  async function n() {
    await (await caches.open(f)).addAll(l);
  }
  a.waitUntil(n());
});
self.addEventListener("activate", (a) => {
  async function n() {
    for (const o of await caches.keys())
      o !== f && await caches.delete(o);
  }
  a.waitUntil(n());
});
self.addEventListener("fetch", (a) => {
  if (a.request.method !== "GET" || !a.request.url.startsWith("http"))
    return;
  async function n() {
    const o = new URL(a.request.url), s = await caches.open(f);
    if (l.includes(o.pathname))
      return s.match(o.pathname);
    try {
      const e = await fetch(a.request);
      return e.status === 200 && s.put(a.request, e.clone()), e;
    } catch {
      return s.match(a.request);
    }
  }
  a.respondWith(n());
});
