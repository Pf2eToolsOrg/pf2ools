const t = /* @__PURE__ */ location.pathname.split("/").slice(0, -1).join("/"), r = [
  t + "/_app/immutable/entry/app.9b4bcd3d.js",
  t + "/_app/immutable/chunks/0.c56273c7.js",
  t + "/_app/immutable/chunks/1.49ddcf08.js",
  t + "/_app/immutable/chunks/2.b2fcb3d9.js",
  t + "/_app/immutable/chunks/3.677d17fa.js",
  t + "/_app/immutable/assets/ProgressBar.4f1e9ba5.css",
  t + "/_app/immutable/chunks/ProgressBar.svelte_svelte_type_style_lang.ec6fbd8a.js",
  t + "/_app/immutable/chunks/index.363b4140.js",
  t + "/_app/immutable/chunks/index.69e6a8df.js",
  t + "/_app/immutable/chunks/singletons.8354a009.js",
  t + "/_app/immutable/chunks/stores.6d7e77ce.js",
  t + "/_app/immutable/assets/fa-brands-400.20c4a58b.ttf",
  t + "/_app/immutable/assets/fa-brands-400.74833209.woff2",
  t + "/_app/immutable/assets/fa-regular-400.528d022d.ttf",
  t + "/_app/immutable/assets/fa-regular-400.8e7e5ea1.woff2",
  t + "/_app/immutable/assets/fa-solid-900.67a65763.ttf",
  t + "/_app/immutable/assets/fa-solid-900.7152a693.woff2",
  t + "/_app/immutable/assets/fa-v4compatibility.0515a423.ttf",
  t + "/_app/immutable/assets/fa-v4compatibility.694a17c3.woff2",
  t + "/_app/immutable/entry/start.5f1f6bf3.js",
  t + "/_app/immutable/entry/error.svelte.fa434491.js",
  t + "/_app/immutable/assets/_layout.d5d63895.css",
  t + "/_app/immutable/entry/_layout.svelte.3bd6bda4.js",
  t + "/_app/immutable/entry/_page.svelte.c2d11e1c.js",
  t + "/_app/immutable/assets/_page.16c46a82.css",
  t + "/_app/immutable/entry/licenses-page.svelte.8fd96698.js"
], i = [
  t + "/data/.git",
  t + "/data/.gitignore",
  t + "/data/CUP.license",
  t + "/data/LICENSE",
  t + "/data/README.md",
  t + "/data/core/sources.json",
  t + "/fonts/AlbertusMT.ttf",
  t + "/fonts/Basing.ttf",
  t + "/fonts/Blambot-Casual-Regular.ttf",
  t + "/fonts/Convergence-Regular.ttf",
  t + "/fonts/Dax-Regular.ttf",
  t + "/fonts/Dax-bold.ttf",
  t + "/fonts/Gin-Regular.ttf",
  t + "/fonts/OFL.txt",
  t + "/fonts/Pathfinder2eActions.ttf",
  t + "/fonts/Quicksand.ttf",
  t + "/fonts/Roboto-regular.ttf",
  t + "/fonts/Sabon-Bold.ttf",
  t + "/fonts/Sabon-BoldItalic.ttf",
  t + "/fonts/Sabon-Italic.ttf",
  t + "/fonts/Sabon-Roman.ttf",
  t + "/fonts/SabonLTStd-Bold.ttf",
  t + "/fonts/SabonLTStd-BoldItalic.ttf",
  t + "/fonts/SabonLTStd-Italic.ttf",
  t + "/fonts/SabonLTStd-Roman.ttf",
  t + "/fonts/Taroca.ttf",
  t + "/fonts/fa-light-300.eot",
  t + "/fonts/fa-light-300.ttf",
  t + "/fonts/fa-light-300.woff",
  t + "/fonts/fa-light-300.woff2",
  t + "/fonts/fa-regular-400.eot",
  t + "/fonts/fa-regular-400.ttf",
  t + "/fonts/fa-regular-400.woff",
  t + "/fonts/fa-regular-400.woff2",
  t + "/fonts/fa-solid-900.eot",
  t + "/fonts/fa-solid-900.ttf",
  t + "/fonts/fa-solid-900.woff",
  t + "/fonts/fa-solid-900.woff2",
  t + "/fonts/glyphicons-halflings-regular.eot",
  t + "/fonts/glyphicons-halflings-regular.svg",
  t + "/fonts/glyphicons-halflings-regular.ttf",
  t + "/fonts/glyphicons-halflings-regular.woff",
  t + "/fonts/glyphicons-halflings-regular.woff2",
  t + "/fonts/good-pro-400.ttf",
  t + "/fonts/good-pro-400.woff",
  t + "/fonts/good-pro-400.woff2",
  t + "/fonts/good-pro-700.ttf",
  t + "/fonts/good-pro-700.woff",
  t + "/fonts/good-pro-700.woff2",
  t + "/fonts/good-pro-condensed-400.ttf",
  t + "/fonts/good-pro-condensed-400.woff",
  t + "/fonts/good-pro-condensed-700.ttf",
  t + "/fonts/good-pro-condensed-700.woff",
  t + "/fonts/good-pro-condensed-700.woff2",
  t + "/fonts/good-pro-condensed-italic-400.ttf",
  t + "/fonts/good-pro-condensed-italic-400.woff",
  t + "/fonts/good-pro-condensed-italic-700.ttf",
  t + "/fonts/good-pro-condensed-italic-700.woff",
  t + "/fonts/good-pro-condensed-italic-700.woff2",
  t + "/fonts/good-pro-italic-400.ttf",
  t + "/fonts/good-pro-italic-400.woff",
  t + "/fonts/good-pro-italic-400.woff2",
  t + "/fonts/good-pro-italic-700.ttf",
  t + "/fonts/good-pro-italic-700.woff",
  t + "/fonts/good-pro-italic-700.woff2",
  t + "/fonts/languages/CRB/Draconic/Iokharic Bold Italic.otf",
  t + "/fonts/languages/CRB/Draconic/Iokharic Bold.otf",
  t + "/fonts/languages/CRB/Draconic/Iokharic Italic.otf",
  t + "/fonts/languages/CRB/Draconic/Iokharic.otf",
  t + "/fonts/languages/CRB/Dwarven/Davek Bold Italic.otf",
  t + "/fonts/languages/CRB/Dwarven/Davek Bold.otf",
  t + "/fonts/languages/CRB/Dwarven/Davek Italic.otf",
  t + "/fonts/languages/CRB/Dwarven/Davek.otf",
  t + "/fonts/languages/CRB/Dwarven/Dethek Alt.ttf",
  t + "/fonts/languages/CRB/Dwarven/Dethek Bold Italic.otf",
  t + "/fonts/languages/CRB/Dwarven/Dethek Bold.otf",
  t + "/fonts/languages/CRB/Dwarven/Dethek Italic.otf",
  t + "/fonts/languages/CRB/Dwarven/Dethek Stone.ttf",
  t + "/fonts/languages/CRB/Dwarven/Dethek.otf",
  t + "/fonts/languages/CRB/Dwarven/Olde Dethek Italic.otf",
  t + "/fonts/languages/CRB/Dwarven/Olde Dethek.otf",
  t + "/fonts/languages/CRB/Elven/Espruar 2e.ttf",
  t + "/fonts/languages/CRB/Elven/Espruar 3e Bold Italic.otf",
  t + "/fonts/languages/CRB/Elven/Espruar 3e Bold.otf",
  t + "/fonts/languages/CRB/Elven/Espruar 3e Italic.otf",
  t + "/fonts/languages/CRB/Elven/Espruar 3e.otf",
  t + "/fonts/languages/CRB/Elven/Espruar 3e.ttf",
  t + "/fonts/languages/CRB/Elven/Espruar 5e.ttf",
  t + "/fonts/languages/CRB/Elven/Olde Espruar.otf",
  t + "/fonts/languages/CRB/Elven/Rellanic Bold Italic.otf",
  t + "/fonts/languages/CRB/Elven/Rellanic Bold.otf",
  t + "/fonts/languages/CRB/Elven/Rellanic Italic.otf",
  t + "/fonts/languages/CRB/Elven/Rellanic.otf",
  t + "/fonts/languages/CRB/Human/Harpers.ttf",
  t + "/fonts/languages/CRB/Human/Olde Thorass.otf",
  t + "/fonts/languages/CRB/Human/Thorass Bold Italic.otf",
  t + "/fonts/languages/CRB/Human/Thorass Bold.otf",
  t + "/fonts/languages/CRB/Human/Thorass Italic.otf",
  t + "/fonts/languages/CRB/Human/Thorass.otf",
  t + "/fonts/languages/CRB/Infernal/Barazhad Bold Italic.otf",
  t + "/fonts/languages/CRB/Infernal/Barazhad Bold.otf",
  t + "/fonts/languages/CRB/Infernal/Barazhad Italic.otf",
  t + "/fonts/languages/CRB/Infernal/Barazhad.otf",
  t + "/fonts/languages/CRB/Infernal/Infernal.ttf",
  t + "/icons/Background.svg",
  t + "/icons/NoBackground.svg",
  t + "/icons/safari-pinned-tab.svg"
], g = "1682459455529", f = `cache-${g}`, l = [
  ...r,
  // the app itself
  ...i.filter((a) => !a.startsWith("/data"))
  // everything in `static` but the actual data
];
self.addEventListener("install", (a) => {
  async function s() {
    await (await caches.open(f)).addAll(l);
  }
  a.waitUntil(s());
});
self.addEventListener("activate", (a) => {
  async function s() {
    for (const o of await caches.keys())
      o !== f && await caches.delete(o);
  }
  a.waitUntil(s());
});
self.addEventListener("fetch", (a) => {
  if (a.request.method !== "GET")
    return;
  async function s() {
    const o = new URL(a.request.url), n = await caches.open(f);
    if (l.includes(o.pathname))
      return n.match(o.pathname);
    try {
      const e = await fetch(a.request);
      return e.status === 200 && n.put(a.request, e.clone()), e;
    } catch {
      return n.match(a.request);
    }
  }
  a.respondWith(s());
});
